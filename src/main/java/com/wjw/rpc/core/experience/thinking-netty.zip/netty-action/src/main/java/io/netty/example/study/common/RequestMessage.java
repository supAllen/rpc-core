package io.netty.example.study.common;

/**
 * @description:
 * @author: wang.jianwen
 * @create: 2020-12-26 16:14
 **/
public class RequestMessage extends Message {
    @Override
    public Class getMessageBodyDecodeClass(int opCode) {
        return Object.class;
    }
}
