package io.netty.example.study.codec.handler;

import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.example.study.common.MessageBody;
import io.netty.example.study.common.RequestMessage;
import io.netty.example.study.common.ResponseMessage;

/**
 * @description: SimpleChannelInboundHandler 可以帮忙释放 bytebuf
 * @author: wang.jianwen
 * @create: 2020-12-26 16:20
 **/
public class OrderServerProcessHandler extends SimpleChannelInboundHandler<RequestMessage> {
    @Override
    protected void channelRead0(ChannelHandlerContext ctx, RequestMessage requestMessage) throws Exception {
        MessageBody messageBody = requestMessage.getMessageBody();
        // TODO exec business
        Object res = "success";

        ResponseMessage responseMessage = new ResponseMessage();
        responseMessage.setMessageHeader(requestMessage.getMessageHeader());
        responseMessage.setMessageBody(messageBody);

        ctx.writeAndFlush(responseMessage);
    }
}
