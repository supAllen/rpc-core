package io.netty.example.study.util;

import java.util.concurrent.atomic.AtomicLong;

/**
 * @description:
 * @author: wang.jianwen
 * @create: 2020-12-26 16:07
 **/
public class IDUtils {
    private static final AtomicLong IDX = new AtomicLong();

    private IDUtils() {}

    public static long nextId() {
        return IDX.incrementAndGet();
    }
}
