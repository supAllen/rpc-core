package io.netty.example.study.common;

import lombok.Data;

/**
 * @description:
 * @author: wang.jianwen
 * @create: 2020-12-26 15:56
 **/
@Data
public class MessageHeader {
    private Integer version = 1;
    private Long streamId;
    private Integer opCode;
}
