package io.netty.example.study.codec;

import io.netty.handler.codec.LengthFieldPrepender;

/**
 * @description:
 * @author: wang.jianwen
 * @create: 2020-12-26 16:09
 **/
public class OrderFrameEncoder extends LengthFieldPrepender {
    public OrderFrameEncoder() {
        super(2);
    }
}
