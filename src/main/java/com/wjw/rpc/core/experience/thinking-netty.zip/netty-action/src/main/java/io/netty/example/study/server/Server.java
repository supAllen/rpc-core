package io.netty.example.study.server;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.example.study.codec.OrderFrameDecoder;
import io.netty.example.study.codec.OrderFrameEncoder;
import io.netty.example.study.codec.OrderProtocolDecoder;
import io.netty.example.study.codec.OrderProtocolEncoder;
import io.netty.example.study.codec.handler.OrderServerProcessHandler;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.logging.LoggingHandler;

/**
 * @description:
 * @author: wang.jianwen
 * @create: 2020-12-26 16:37
 **/
public class Server {

    public static void main(String[] args) throws InterruptedException {
        ServerBootstrap bootstrap = new ServerBootstrap();
        bootstrap.channel(NioServerSocketChannel.class);

        bootstrap.handler(new LoggingHandler(LogLevel.INFO));
        bootstrap.group(new NioEventLoopGroup());

        bootstrap.childHandler(new ChannelInitializer<NioSocketChannel>() {
            @Override
            protected void initChannel(NioSocketChannel ch) throws Exception {
                ChannelPipeline pipeline = ch.pipeline();

                pipeline.addLast("frameDecoder", new OrderFrameDecoder());
                pipeline.addLast("frameEncoder", new OrderFrameEncoder());
                pipeline.addLast("protocolEncoder", new OrderProtocolEncoder());
                pipeline.addLast("protocolDecoder", new OrderProtocolDecoder());

                pipeline.addLast("log", new LoggingHandler(LogLevel.INFO));
                pipeline.addLast("processHandler", new OrderServerProcessHandler());
            }
        });

        ChannelFuture channelFuture = bootstrap.bind(8090).sync();

        channelFuture.channel().closeFuture().sync();
    }
}
