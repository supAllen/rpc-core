package io.netty.example.study.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.lang.reflect.Type;

public class GsonUtils {

    private static final Gson GSON = new Gson();

    public static String toJsonString(Object obj) {
        return GSON.toJson(obj);
    }

    public static<T>  T toObject(String jsonString, Class<T> clazz) {
        return GSON.fromJson(jsonString, clazz);
    }

    public static<T>  T fromJson(String jsonString, Class<T> clazz) {
        return GSON.fromJson(jsonString, clazz);
    }

    public static<T> T fromJson(String jsonString, Type type) {
        return GSON.fromJson(jsonString, type);
    }

    public static void dumpJson(Object obj) {
        String str = toJsonString(obj);
        Gson formatGson = new GsonBuilder().setPrettyPrinting().create();
        System.out.println(formatGson.toJson(obj));
    }
}
