package io.netty.example.study.common;

/**
 * @description:
 * @author: wang.jianwen
 * @create: 2020-12-26 16:22
 **/
public class ResponseMessage extends Message{
    @Override
    public Class getMessageBodyDecodeClass(int opCode) {
        return Object.class;
    }
}
