package io.netty.example.study.codec;

import io.netty.handler.codec.LengthFieldBasedFrameDecoder;

/**
 * @description: 解决粘包和半包问题
 * @author: wang.jianwen
 * @create: 2020-12-26 16:09
 **/
public class OrderFrameDecoder extends LengthFieldBasedFrameDecoder {
    public OrderFrameDecoder() {
        super(Integer.MAX_VALUE, 0, 2, 0, 2);
    }
}
